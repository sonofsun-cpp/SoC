import React from "react";

function Header() {
    return (
        <header><h1>DigiCode - The next generation online code editor</h1></header>
    );
}

export default Header;