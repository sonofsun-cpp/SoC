const notes = [
  {
    key: 1,
    title: "Project 1",
    content: "Language: C++"
    },
  {
    key: 2,
    title: "Project 2",
    content: "Language: C++"
  },
  {
    key: 3,
    title: "Project 3",
    content: "Language: JavaScript"
  },
  {
    key: 4,
    title: "Project 4",
    content: "Language: Python"
  },
  {
    key: 5,
    title: "Project 5",
    content: "Language: Jupyter Notebook"
  },
  {
    key: 6,
    title: "Project 6",
    content: "Language: Jupyter Notebook"
  }
];

export default notes;